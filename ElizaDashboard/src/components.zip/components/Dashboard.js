import React from "react";
import { useParams , useNavigate  } from "react-router-dom";
import axios from "axios";

const Dashboard = () => {
  const { userId } = useParams();  // Get userId from URL
  const navigate = useNavigate();

  const handleNavigate = (path) => {
    navigate(path);
  };


  return (
    <div className="bg-gray-100 min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-gray-800 text-white p-8 w-full flex justify-between items-center">
        <h1 className="text-4xl font-semibold">Welcome to the Platform</h1>
      </header>

      <div className="flex flex-1">

        {/* Main Content */}
        <div  className="main">
          <div>
          <section className="text-center p-8 mb-8 bg-gray-200">
                <h2 className="text-3xl font-semibold text-gray-800 mb-4">
                  Explore the Ecosystem
                </h2>
                <p className="text-lg text-gray-600">
                  Our platform connects startups, investors, mentors, incubators, and collaborators. Each of these categories is a vital part of the innovation ecosystem, and we invite you to explore and get involved.
                </p>
              </section>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Card 1: Startups */}
              <div className="flex flex-col items-center p-8 bg-white shadow-xl rounded-lg hover:shadow-2xl transition-shadow duration-300 transform hover:scale-105 max-w-xs mx-auto">
                <h2 className="text-3xl font-semibold text-center mb-4 text-gray-800">
                  Startups
                </h2>
                <p className="text-center mb-6 text-gray-600">
                  Explore innovative startups from around the world. Join a community of entrepreneurs!
                </p>
                <button
                  onClick={() => handleNavigate("/startups")}
                  className="bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors duration-300"
                >
                  Go to Startups
                </button>
              </div>

              {/* Card 2: Investors */}
              <div className="flex flex-col items-center p-8 bg-white shadow-xl rounded-lg hover:shadow-2xl transition-shadow duration-300 transform hover:scale-105 max-w-xs mx-auto">
                <h2 className="text-3xl font-semibold text-center mb-4 text-gray-800">
                  Investors
                </h2>
                <p className="text-center mb-6 text-gray-600">
                  Find investors who are ready to support your next big idea and help you grow!
                </p>
                <button
                   onClick={() => {
                    console.log("Navigating to /investors");
                    handleNavigate("/investors")}}
                  className="bg-green-600 text-white py-3 px-6 rounded-lg hover:bg-green-700 transition-colors duration-300"
                >
                  Go to Investors
                </button>
              </div>

              {/* Card 3: Incubators */}
              <div className="flex flex-col items-center p-8 bg-white shadow-xl rounded-lg hover:shadow-2xl transition-shadow duration-300 transform hover:scale-105 max-w-xs mx-auto">
                <h2 className="text-3xl font-semibold text-center mb-4 text-gray-800">
                  Reserchers
                </h2>
                <p className="text-center mb-6 text-gray-600">
                  Join an incubator and accelerate your startup's growth with expert mentorship!
                </p>
                <button
                  onClick={() => handleNavigate("/reserchers")}
                  className="bg-orange-600 text-white py-3 px-6 rounded-lg hover:bg-orange-700 transition-colors duration-300"
                >
                  Go to Incubators
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mt-8">
              {/* Card 4: Mentors */}
              <div className="flex flex-col items-center p-8 bg-white shadow-xl rounded-lg hover:shadow-2xl transition-shadow duration-300 transform hover:scale-105 max-w-xs mx-auto">
                <h2 className="text-3xl font-semibold text-center mb-4 text-gray-800">
                  Mentors
                </h2>
                <p className="text-center mb-6 text-gray-600">
                  Get guidance from experienced mentors who will help you navigate your entrepreneurial journey!
                </p>
                <button
                   onClick={() => handleNavigate("/mentors")}
                  className="bg-purple-600 text-white py-3 px-6 rounded-lg hover:bg-purple-700 transition-colors duration-300"
                >
                  Go to Mentors
                </button>
              </div>

              {/* Card 5: Collaborators */}
              <div className="flex flex-col items-center p-8 bg-white shadow-xl rounded-lg hover:shadow-2xl transition-shadow duration-300 transform hover:scale-105 max-w-xs mx-auto">
                <h2 className="text-3xl font-semibold text-center mb-4 text-gray-800">
                  Admin
                </h2>
                <p className="text-center mb-6 text-gray-600">
                  Connect with potential collaborators and expand your network to scale your project.
                </p>
                <button
                  // onClick={() => handleNavigate("/collaborators")}
                  className="bg-teal-600 text-white py-3 px-6 rounded-lg hover:bg-teal-700 transition-colors duration-300"
                >
                  Go to Collaborators
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-800 text-white p-6 mt-8 w-full">
        <div className="text-center">
          <p>&copy; 2024 All Rights Reserved. Your Company Name</p>
        </div>
      </footer>
    </div>
  );
};

export default Dashboard;
